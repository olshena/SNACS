## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  warning = FALSE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(SNACS)

## ----echo = TRUE--------------------------------------------------------------

dim(mutMat)
mutMat[1:4,1:4]


## ----echo = TRUE--------------------------------------------------------------

dim(hashMat)
hashMat[,1:4]


## ----echo = TRUE--------------------------------------------------------------

dim(depthTotalMat)
depthTotalMat[1:4,1:4]


## ----echo = TRUE--------------------------------------------------------------

dim(depthAltMat)
depthAltMat[1:4,1:4]


## ----echo = TRUE--------------------------------------------------------------

## Parameters mut, hashes, exptName are mandatory while depthTotalMat, depthAltMat and hashColors are optional. depthTotalMat and depthAltMat are used for making doubletD calls
exptName <- "snacsExpt"
hashColors <- c("indianred2","green3","dodgerblue3")

snacsObj <- SNACSList(mut=mutMat,hashes=hashMat,exptName=exptName,depthTotal=depthTotalMat,depthAlt=depthAltMat,hashColors=hashColors)
snacsObj


## ----echo = TRUE--------------------------------------------------------------

snacsObj <- runSNACS(snacsObj=snacsObj)

snacsObj

snacsObj$annCell[1:4,]


## ----echo = TRUE--------------------------------------------------------------

snacsObj=runSNACSplusDoubletD(snacsObj)

snacsObj$annCell[1:4,]


## ----fig.show = "hold", out.width = "100%", echo = TRUE-----------------------

createHeatmap(snacsObj,
   cell_anno_var=c("snacsPlusDoubletD","doubletD","snacsRnd2","snacsRnd1",snacsObj$annHash$hashNames,"clustBestSNPs_hclust"),
   cell_anno_name=c("snacs+DD","doubletD","snacsRnd2","snacsRnd1",snacsObj$annHash$hashNames,"cluster"),
   outputFormat="")


