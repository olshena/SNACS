## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(SNACS)

## ---- echo = TRUE-------------------------------------------------------------

dim(mutMat)
mutMat[1:4,1:4]


## ---- echo = TRUE-------------------------------------------------------------

dim(hashMat)
hashMat[,1:4]


## ---- echo = TRUE-------------------------------------------------------------

## Parameters mut, hashes, exptName are mandatory while hashColors is optional
exptName <- "snacsExpt"
hashColors <- c("green3","indianred2","dodgerblue3")

snacsObj <- SNACSList(mut=mutMat,hashes=hashMat,exptName=exptName,hashColors=hashColors)
snacsObj


## ---- echo = TRUE-------------------------------------------------------------

snacsObj <- imputeMissingMutations(snacsObj=snacsObj)
snacsObj


## ---- echo = TRUE-------------------------------------------------------------

## The p-value for selecting best SNPs can be specified
pvSnpThres <- 0.05

snacsObj <- getBestSNPs(snacsObj,pvSnpThres=pvSnpThres)
snacsObj


## ---- fig.show = "hold", out.width = "50%", echo = TRUE-----------------------

generateHashDensityPlot(snacsObj)


## ---- echo = TRUE-------------------------------------------------------------

snacsObj=makeHashCall(snacsObj)

## The hash calls are saved in the "annCell" table in the SNACSList object
snacsObj$annCell[1:4,]


## ---- fig.show = "hold", out.width = "50%", echo = TRUE-----------------------

createHeatmap(snacsObj,
   cell_anno_var=c("hashCall",snacsObj$annHash$hashNames,"clustRankedSNPs_hclust"),
   cell_anno_name=c("hash",snacsObj$annHash$hashNames,"cluster"),
   outputFormat="")


